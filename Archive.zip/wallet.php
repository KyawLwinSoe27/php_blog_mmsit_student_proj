<?php 

require_once "./core/auth.php";
require_once "./template/header.php";

if(isset($_POST['transfer'])){
    if(money_transfer()){
        linkTo("wallet.php");
    }
}

?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4>
                        <i class="feather-dollar-sign"></i> My Wallet
                    </h4>
                    <a href="" class="btn btn-outline-primary">
                        <i class="feather-dollar-sign"></i> My Money : <?php echo user($_SESSION['user']['id'])['money']; ?>
                    </a>
                </div>
                <hr>
                <form method="post" class="w-75">
                    <div class="input-group mb-3">
                        <select name="to_user" class="custom-select mr-2 w-25">
                            <option value="" class="selected disabled">Select Account</option>
                            <?php foreach(users() as $user) {  ?>
                                <?php if($user['id'] != $_SESSION['user']['id']) { ?>
                                    <option value="<?php echo $user['id']; ?>"><?php echo $user['name']; ?></option>
                                    <?php } ?>
                            <?php } ?>
                        </select>
                        <input type="number" class="form-control mr-2 w-25" name="amount" min="100" max="<?php echo user($_SESSION['user']['id'])['money']; ?>" placeholder="amount">
                        <input type="text" class="form-control mr-2" name="description" placeholder="Reason for transfer">
                        <button class="btn btn-primary" name="transfer">Transfer</button>
                    </div>
                </form>

                <hr>

                <table class="table table-bordered table-hover">
                    <thead>
                        <th>#</th>
                        <th>Sender</th>
                        <th>Receiver</th>
                        <th>Amount</th>
                        <th>Description</th>
                        <th>Date / Time</th>
                    </thead>
                    <tbody>
                        <?php foreach(transcation_lists() as $t) { ?>
                            <tr>
                                <td><?php echo $t['id']; ?></td>
                                <td><?php echo user($t['from_user_id'])['name']; ?></td>
                                <td><?php echo user($t['to_user_id'])['name']; ?></td>
                                <td><?php echo $t['amount']; ?></td>
                                <td><?php echo $t['description']; ?></td>
                                <td><?php echo date('d-m-Y / h:i', strtotime($t['created_at'])); ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php require_once "./template/footer.php" ?>