<?php

echo "<pre>";

print_r($_SERVER['HTTP_USER_AGENT']);