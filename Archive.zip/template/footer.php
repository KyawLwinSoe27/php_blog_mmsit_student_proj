</div>
    </div>
</section>
<script src="<?php echo $url ?>assests/vendor/jquery.min.js"></script>
<script src="<?php echo $url ?>assests/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $url; ?>assests/vendor/data_table/jquery.dataTables.min.js"></script>
<script src="<?php echo $url; ?>assests/vendor/data_table/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo $url; ?>assests/vendor/summer_note/summernote-bs4.min.js"></script>
<script src="<?php echo $url ?>assests/js/popper.min.js"></script>
<script src="<?php echo $url ?>assests/js/app.js"></script>
<script>
    const currentLocation = location.href;
    $(".menu-item-link").each(function() {
        let links = $(this).attr("href");
        if(currentLocation == links){
            $(this).addClass("active");
        }
    })
</script>
</body>
</html>