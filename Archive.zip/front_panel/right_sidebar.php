<div class="col-12 col-md-4">
    <div class="card">
        <div class="card-body">
            <?php $username =  $_SESSION['user']['name'];
            date_default_timezone_set('Asia/Yangon');
            $checkTime = date('H');
            ?>
            <h5><?php if($checkTime >= 5 && $checkTime <= 11) {
                echo 'Good Morning';
            } else if($checkTime >= 11 && $checkTime <= 15) {
                echo 'Good Afternoon';
            } else if($checkTime >= 15 && $checkTime <= 19) {
                echo 'Good Evening';
            } else if($checkTime >= 19 && $checkTime <= 22) {
                echo 'Good Night';
            }else {
                echo 'Midnight';
            } ?>, <?php if($_SESSION['user']['name']){
                echo $username;
            }else {
                echo 'Guest';
            } ?> </h5>
            <a href="dashboard.php" class="btn btn-primary mt-2">Go To Dashboard</a>
        </div>
    </div>
    <div class="frontpanel_rightside">
        <h4>Category List</h4>
        <div class="list-group mb-4">
            <a href="index.php" class="list-group-item list-group-item-action <?php echo isset($_GET['category_id']) ? "" : "active" ?>" aria-current="true">
                All Categories
            </a>
            <?php foreach (fcategories() as $c) { ?>
                <a href="categoryPost_list.php?category_id=<?php echo $c['id']; ?>" class="list-group-item list-group-item-action <?php echo isset($_GET['category_id']) ? ($_GET['category_id'] == $c['id'] ? "active" : "") : "" ?>" aria-current="true">
                <?php if($c['ordering'] == 1) { ?>
                    <i class="feather-paperclip"></i>
                <?php } ?>
                <?php echo $c['title'] ?>
                </a>
            <?php } ?>

        </div>
        <div class="searchByDate">
            <h4>Search By Date</h4>
            <div class="card">
                <div class="card-body">
                    <form method="post" action="<?php echo $url; ?>searchByDate.php">
                        <div class="form-group">
                            <label for="">Start Date</label>
                            <input type="date" name="start" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">End Date</label>
                            <input type="date" name="end" class="form-control" required>
                        </div>
                        <button class="btn btn-primary">
                            <i class="feather-calendar"></i> Search
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div>
            <h4>Advertisement</h4>
            <img src="<?php echo $url; ?>assests/img/ads.jpeg" alt="ads sample" class="w-100 rounded">
        </div>
        
    </div>
</div>