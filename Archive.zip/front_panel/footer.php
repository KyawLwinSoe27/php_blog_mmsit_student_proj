<script src="<?php echo $url ?>assests/vendor/jquery.min.js"></script>
<script src="<?php echo $url ?>assests/js/popper.min.js"></script>
<script src="<?php echo $url ?>assests/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $url ?>assests/js/app.js"></script>
</body>
</html>