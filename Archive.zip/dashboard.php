<?php require_once "./core/auth.php"; ?>
<?php include "./template/header.php"; ?>
<div class="row">
    <div class="col-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card mb-4 status-card" onclick="go('#')">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-3">
                        <i class="feather-heart h1 text-primary"></i>
                    </div>
                    <div class="col-9">
                        <p class="mb-1 h4 font-weight-bolder">
                            <span class="counter-up"><?php echo countTotal('viewer'); ?></span>
                        </p>
                        <p class="mb-0 text-black-50">Today Visitors</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card mb-4 status-card" onclick="go('<?php echo $url; ?>post_list.php')">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-3">
                        <i class="feather-list h1 text-primary"></i>
                    </div>
                    <div class="col-9">
                        <p class="mb-1 h4 font-weight-bolder">
                            <span class="counter-up"><?php echo countTotal('posts') ?></span>
                        </p>
                        <p class="mb-0 text-black-50">Total Posts</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card mb-4 status-card" onclick="go('<?php echo $url; ?>category_add.php')">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-3">
                        <i class="feather-layers h1 text-primary"></i>
                    </div>
                    <div class="col-9">
                        <p class="mb-1 h4 font-weight-bolder">
                            <span class="counter-up"><?php echo countTotal('categories'); ?></span>
                        </p>
                        <p class="mb-0 text-black-50">Total Category</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card mb-4 status-card" onclick="go('<?php echo $url; ?>user_list.php')">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-3">
                        <i class="feather-users h1 text-primary"></i>
                    </div>
                    <div class="col-9">
                        <p class="mb-1 h4 font-weight-bolder">
                            <span class="counter-up"><?php echo countTotal('users'); ?></span>
                        </p>
                        <p class="mb-0 text-black-50">Total Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<div class="row">
    <div class="col-12 col-xl-7">
        <div class="card overflow-hidden shadow mb-4">
            <div class="">
                <div class="d-flex justify-content-between align-items-center p-3">
                    <h4 class="mb-0">Visitors</h4>
                    <div class="">
                        <img src="<?php echo $url; ?>assests/img/user/avatar1.jpg" class="ov-img rounded-circle" alt="">
                        <img src="<?php echo $url; ?>assests/img/user/avatar2.jpg" class="ov-img rounded-circle" alt="">
                        <img src="<?php echo $url; ?>assests/img/user/avatar3.jpg" class="ov-img rounded-circle" alt="">
                        <img src="<?php echo $url; ?>assests/img/user/avatar4.jpg" class="ov-img rounded-circle" alt="">
                        <img src="<?php echo $url; ?>assests/img/user/avatar5.jpg" class="ov-img rounded-circle" alt="">
                    </div>
                </div>

                <canvas id="ov" height="135"></canvas>

            </div>
        </div>
    </div>
    <div class="col-12 col-md-6 col-xl-5">
        <div class="card mb-4">
            <div class="card-body">

                <div class="d-flex justify-content-between align-items-center p-3">
                    <h4 class="mb-0">Post Quantity by Category</h4>
                    <div class="">
                        <i class="feather-pie-chart h4 mb-0 text-primary"></i>
                    </div>
                </div>
                <canvas id="op" height="200"></canvas>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <p class="h4">Recent Posts</p>
                    <div class="d-flex flex-column mb-2 align-items-end">

                        <?php
                        $current_user_id = $_SESSION['user']['id'];
                        $totalPost = countTotal('posts');
                        $current_user_post = countTotal("posts", "user_id = $current_user_id");
                        $percentage = ($current_user_post / $totalPost) * 100;


                        ?>
                    
                        <small class="mb-1">Your Post: <?php echo $current_user_post; ?></small>
                        <div  class="progress" style="width: 200px;">
                        <div class="progress-bar  progress-bar-striped progress-bar-animated" role="progressbar" style="width: <?php echo floor($percentage) ?>%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
                <table class="table table-hover" id="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Category</th>
                            <?php if ($_SESSION['user']['role'] == 0) {; ?> <th>User</th> <?php }; ?>
                            <th>Viewer</th>
                            <th>Control</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach (dashboardPosts(5) as $p) {
                        ?>
                            <tr>
                                <td><?php echo $p['id']; ?></td>
                                <td><?php echo short($p['title']); ?></td>
                                <td><?php echo short(strip_tags(html_entity_decode($p['description']))); ?></td>
                                <td class="text-nowrap"><?php echo category($p['category_id'])['title'] ?></td>
                                <?php if ($_SESSION['user']['role'] == 0) {; ?> <td><?php echo user($p['user_id'])['name']; ?></td> <?php }; ?>
                                <td><?php echo count(viewerCountByPost($p['id'])); ?></td>
                                <td>
                                    <a href="post_details.php?id=<?php echo $p['id']; ?>" class="btn btn-outline-info">
                                        <i class="feather-info"></i>
                                    </a>
                                    <a href="post_delete.php?id=<?php echo $p['id'];  ?>" onclick="return confirm('Are you sure to delete this category?')" class="btn btn-outline-danger">

                                        <i class="feather-trash-2 fa-fw"></i>

                                    </a>

                                    <a href="post_edit.php?id=<?php echo $p['id'];  ?>" class="btn btn-outline-warning">

                                        <i class="feather-edit-2 fa-fw"></i>

                                    </a>

                                </td>
                                <td><?php echo showTime($p['created_at']) ?></td>
                            </tr>
                        <?php  } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include "./template/footer.php"; ?>

<script src="<?php echo $url; ?>assests/vendor/way_point/jquery.waypoints.js"></script>
<script src="<?php echo $url; ?>assests/vendor/counter_up/counter_up.js"></script>
<script src="<?php echo $url; ?>assests/vendor/chart_js/chart.min.js"></script>

<script>
    $('.counter-up').counterUp({
        delay: 10,
        time: 1000
    });

    <?php
    $dateArr = [];
    $viewerArr = [];
    $transactionArr = [];

    // $today = date('Y-m-d');
    // $date = date_create($today);
    // date_sub($date, date_interval_create_from_date_string("3 days")); // today ထဲက ၃ ရက်နုတ်
    // echo date_format($date, "Y-m-d");

    for ($i = 0; $i < 10; $i++) {
        $today = date('Y-m-d');
        $date = date_create($today);
        date_sub($date, date_interval_create_from_date_string("$i days"));
        $current = date_format($date, "Y-m-d");

        array_push($dateArr, $current);
        //sql မှာ created_at ကို date နဲ့ condtition တိုက်လို့မရဘူး ၊ ဘာလို့ဆို timesatmp ဖြစ်နေလို့။
        //အဲ့တာကြောင့် CAST() လုပ်ပြီးမှ စစ်လို့ရမယ် CAST(created_at As DATE)
        $viewer = countTotal('viewer', "CAST(created_at As DATE) = '$current'");
        array_push($viewerArr, $viewer);
        $transcation = countTotal('transcation', "CAST(created_at As DATE) = '$current'");
        array_push($transactionArr, $transcation);
    }


    ?>

    let dateArr = <?php echo json_encode($dateArr) ?>; // date ၁၀ရက်စာ ပြောင်းပြန်ထုတ်ရမည် date_sub
    let viewerCountArr = <?php echo json_encode($viewerArr) ?>; // တရက်ကို လူဘယ်နှယောက်ကြည့်လဲ
    let transcationArr = <?php echo json_encode($transactionArr); ?>

    let ov = document.getElementById('ov').getContext('2d');
    let ovChart = new Chart(ov, {
        type: 'line',
        data: {
            labels: dateArr,
            datasets: [{
                    label: 'Viewer Count',
                    data: viewerCountArr,
                    backgroundColor: [
                        '#007bff30',
                    ],
                    borderColor: [
                        '#007bff',
                    ],
                    borderWidth: 1,
                    tension: 0
                },
                {
                    label: 'Transcation Count',
                    data: transcationArr,
                    backgroundColor: [
                        '#28a74530',
                    ],
                    borderColor: [
                        '#28a745',
                    ],
                    borderWidth: 1,
                    tension: 0
                }
            ]
        },
        options: {
            scales: {
                yAxes: [{
                    display: false,
                    ticks: {
                        beginAtZero: true
                    }
                }],
                xAxes: [{
                    display: false,
                    gridLines: [{
                        display: false
                    }]
                }]
            },
            legend: {
                display: true,
                shape: "circle",
                position: 'top',
                labels: {
                    fontColor: '#333',
                    usePointStyle: true
                }
            }
        }
    });
    <?php
    $category_list = [];
    $post_count = [];
    foreach (categories() as $c) {
        array_push($category_list, $c['title']);
        array_push($post_count, countTotal('posts', "category_id={$c['id']}"));
    }
    echo json_encode($category_list);
    echo json_encode($post_count);

    ?>

    let orderFromPlace = <?php echo json_encode($post_count); ?>;
    let places = <?php echo json_encode($category_list) ?>;
    let bgColors = [
        'rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(255, 206, 86, 0.2)', 'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)'
    ];
    let borderColors = [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)',
        'rgba(255, 159, 64, 1)'
    ]

    let op = document.getElementById('op').getContext('2d');
    let opChart = new Chart(op, {
        type: 'doughnut',
        data: {
            labels: places,
            datasets: [{
                label: '# of Votes',
                data: orderFromPlace,
                backgroundColor: bgColors,
                borderColor: borderColors,
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    display: false,
                    ticks: {
                        beginAtZero: true
                    }
                }],
                xAxes: [{
                    display: false
                }]
            },
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#333',
                    usePointStyle: true
                }
            }
        }
    });
</script>