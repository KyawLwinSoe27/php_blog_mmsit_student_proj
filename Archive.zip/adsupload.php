<?php require_once "./core/auth.php" ?>
<?php require_once "./core/isAdmin.php"; ?>
<?php require_once "./template/header.php" ?>

<div class="row">
    <div class="col-12 col-md-6">
        <div class="card">
            <div class="card-body">
                <?php 
                
                if(isset($_POST['adsupload'])){
                    adsUpload();
                };
                
                ?>
                <form method="post">
                    <div class="form-group">
                        <label>ကြော်ငြာရှင်အမည်</label>
                        <input type="text" name="owner_name" class="form-control" placeholder="ကြော်ငြာရှင်အမည်" required>
                    </div>
                    <div class="form-group">
                        <label>ကြော်ငြာမည့်ပုံ</label>
                        <input type="text" name="photo" class="form-control" placeholder="ကြော်ငြာမည့်ပုံ" required>
                    </div>
                    <div class="form-group">
                        <label>ကြော်ငြာလင့်</label>
                        <input type="text" name="link" class="form-control" placeholder="ကြော်ငြာလင့်" required>
                    </div>
                    <div class="form-group">
                        <label>ကြော်ငြာစတင်မည့်ရက်</label>
                        <input type="date" name="start" class="form-control" placeholder="ကြော်ငြာစတင်မည့်ရက်" >
                    </div>
                    <div class="form-group">
                        <label>ကြော်ငြာသက်တမ်းကုန်မည့်ရက်</label>
                        <input type="date" name="end" class="form-control" placeholder="ကြော်ငြာသက်တမ်းကုန်မည့်ရက်" >
                    </div>
                    <button class="btn btn-primary" type="submit" name="adsupload">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>


<?php require_once "./template/footer.php" ?>